# Name: Mark Schaub
# Course Name: CMP SCI 1250
# Project number 1 - Space Mission Prep Report
# September 7 2026
# This project contains calculations for a space mission, including meals, averages, experiments, and samples
# Section number 1: Misson Data
number_of_astronauts = 6
days_of_mission = 18
meals_each_day = 3
experiments_per_astronaut = 4
samples_per_experiment = 5
emergency_meal_packs = 54
# Section number 2: Calculations
total_astronaut_days = number_of_astronauts * days_of_mission
total_meal_count = meals_each_day * total_astronaut_days
total_experiments = number_of_astronauts * experiments_per_astronaut
total_samples = total_experiments * samples_per_experiment
total_meal_packs = total_meal_count * emergency_meal_packs
average_meals_per_astronaut = total_meal_packs / number_of_astronauts
# Section number 3: Mission preperation report
print(total_astronaut_days)
print(total_meal_count)
print(total_experiments)
print(total_samples)
print(total_meal_packs)
print(average_meals_per_astronaut)
